<?php
$icon = array(
  'manage' => 'fa-solid fa-people-roof',
  'settings' => 'fa-solid fa-wrench',
  'integrasi' => 'fa-solid fa-puzzle-piece',
  'membermenu' => 'fa-solid fa-users',
  'klien' => 'fa-solid fa-people-group',
  'jaringan' => 'fa-solid fa-network-wired',
  'laporankomisi' => 'fa-solid fa-money-bill',
  'produklist' => 'fa-solid fa-cart-plus'  
);
if (isset($settings['url_produk']) && !empty($settings['url_produk'])) {
  $icon[$settings['url_produk']] = 'fa-solid fa-cart-plus';
}
if (isset($settings['url_artikel']) && !empty($settings['url_artikel'])) {
  $icon[$settings['url_artikel']] = 'fa-solid fa-newspaper';
}

$icon = apply_filter('iconmenu',$icon);

echo '<li class="nav-label first">Main Menu</li>';
if (isset($datamember['mem_role']) && $datamember['mem_role'] >= 5) {
  foreach ($menu as $keymenu => $menuadmin) {
    $aktif = 0;
    if (isset($menuadmin['label'])) {
      if (isset($menuadmin['submenu'])) {      
        $submenu = '';
        foreach ($menuadmin['submenu'] as $key => $value) {          
          $mmaktif = '';
          if (isset($slug[1]) && $slug[1] == $key) {
            $aktif = 1;
            $mmaktif = ' class="mm-active"';
          } 

          if (isset($value[2])) {
            if ($datamember['mem_role'] >= $value[2]) {
              $submenu .= '<li'.$mmaktif.'><a href="'.$weburl.'dashboard/'.$key.'">'.$value[0].'</a></li>';
            }
          } else {
            $submenu .= '<li'.$mmaktif.'><a href="'.$weburl.'dashboard/'.$key.'">'.$value[0].'</a></li>';
          }
        }

        if ($submenu != '') {
          if ($aktif == 1) {
            $mmaktif = ' class="mm-active"';
          }
          echo '
          <li '.$mmaktif.'>
            <a class="has-arrow" href="javascript:void()" aria-expanded="false">
            <i class="'.($icon[$keymenu]??='fa-regular fa-user').'"></i>
              <span class="nav-text">'.$menuadmin['label'].'</span>
            </a>
            <ul aria-expanded="false">'.$submenu.'</ul>
          </li>
          ';
        }
      } else {
        echo '
        <li>
          <a href="'.$weburl.$keymenu.'" aria-expanded="false">
          <i class="'.($icon[$keymenu]??='fa-regular fa-user').'"></i>
            <span class="nav-text">'.$menuadmin['label'].'</span>
          </a>
        </li>
        ';
      }
    }
  }
} else {
  foreach ($menu as $keymenu => $menuadmin) {
    if (isset($menuadmin['label'])) {
      if ($keymenu == 'membermenu') {
        $menumember = $menu['membermenu']['submenu'];

        if (isset($settings['klienoff']) && $settings['klienoff'] == 1) {
          unset($menumember['klien']);
        }
        if (isset($settings['networkoff']) && $settings['networkoff'] == 1) {
          unset($menumember['jaringan']);
        }
        
        foreach ($menumember as $key => $value) {
          if (isset($value[2])) {
            if (isset($datamember['mem_role']) && $datamember['mem_role'] >= $value[2]) {
              echo '
              <li>
                <a href="'.$weburl.'dashboard/'.$key.'" aria-expanded="false">
                <i class="'.($icon[$key]??='fa-regular fa-user').'"></i>
                  <span class="nav-text">'.$value[0].'</span>
                </a>
              </li>
              ';
            }
          } else {
            echo '
              <li>
                <a href="'.$weburl.'dashboard/'.$key.'" aria-expanded="false">
                <i class="'.($icon[$key]??='fa-regular fa-user').'"></i>
                  <span class="nav-text">'.$value[0].'</span>
                </a>
              </li>
              ';
          }
        }
      } else {
        if (!isset($menuadmin['submenu'])) {
          echo '
            <li>
              <a href="'.$weburl.$keymenu.'" aria-expanded="false">
              <i class="'.($icon[$keymenu]??='fa-regular fa-user').'"></i>
                <span class="nav-text">'.$menuadmin['label'].'</span>
              </a>
            </li>
            ';
        }
      }
    }
  }
}
/*
echo '
<li class="nav-item">
  <a class="nav-link" href="'.$weburl.($settings['url_artikel']??='artikel').'">
  <i class="fa-solid fa-newspaper"></i>
  <span class="nav-text">'.ucwords($settings['url_artikel']??='artikel').'</span>
  </a>
</li>';

if (isset($settings['url_produk']) && !empty($settings['url_produk'])) {
  echo '
<li class="nav-item">
  <a class="nav-link" href="'.$weburl.($settings['url_produk']??='produk').'">
  <i class="fa-solid fa-cart-plus"></i>
  <span class="nav-text">'.ucwords($settings['url_produk']??='produk').'</span></a>
</li>';
}
*/
do_action('nav_menu');