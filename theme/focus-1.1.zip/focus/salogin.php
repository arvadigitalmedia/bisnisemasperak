<?php 
if (!defined('IS_IN_SCRIPT')) { die(); exit(); }
if (isset($_POST['username']) && filter_var($_POST['username'],FILTER_VALIDATE_EMAIL) 
  && isset($_POST['password']) && !empty($_POST['password'])) {
  $datamember = db_row("SELECT * FROM `sa_member` WHERE `mem_email`='".cek($_POST['username'])."'");
  if (isset($datamember['mem_email'])) {
    if (validate_password($_POST['password'],$datamember['mem_password'])) {
      $id = $datamember['mem_id'];
      $hash = sha1(rand(0,500).microtime().SECRET);
      $signature = sha1(SECRET . $hash . $id);
      $cookie = base64_encode($signature . "-" . $hash . "-" . $id);
      setcookie('authentication', $cookie,time()+36000,'/');
      db_query("UPDATE `sa_member` SET `mem_lastlogin`='".date('Y-m-d H:i:s')."' WHERE `mem_id`=".$id);
      if (isset($_GET['redirect'])) {
        if (substr($_GET['redirect'],0,1) == '/') {
          $gored = substr($_GET['redirect'],1);
        } else {
          $gored = $_GET['redirect'];
        }
        header('Location:'.$weburl.$gored);
      } else {
        header('Location:'.$weburl.'dashboard');
      }
    } else {
        $error = 'Email atau Password anda salah.';
    }
  } else {
    $error = 'Email anda salah.';
  }
}
?>
<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Login</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?= $weburl.$favicon;?>">
    <link href="<?= $weburl;?>theme/focus/css/style.css" rel="stylesheet">
    <link href="<?=$weburl;?>fontawesome/css/fontawesome.min.css" rel="stylesheet" />
    <link href="<?=$weburl;?>fontawesome/css/regular.min.css" rel="stylesheet" />
    <link href="<?=$weburl;?>fontawesome/css/solid.min.css" rel="stylesheet" /> 
    <style type="text/css">
        .password-wrapper {
          position: relative;
        }
        
        .password-wrapper input[type="password"] {
          padding-right: 30px; /* Ruang untuk ikon */
        }
        
        .password-wrapper .toggle-password {
          position: absolute;
          top: 50%;
          right: 5px;
          transform: translateY(-50%);
          cursor: pointer;
        }
    </style>
    <script>
      function togglePassword() {
        var passwordInput = document.getElementById("password");
        var toggleBtn = document.getElementById("togglePassword");

        if (passwordInput.type === "password") {
          passwordInput.type = "text";
          toggleBtn.innerHTML = '<i class="fas fa-eye-slash text-secondary"></i>';
        } else {
          passwordInput.type = "password";
          toggleBtn.innerHTML = '<i class="fas fa-eye text-secondary"></i>';
        }
      }
    </script>
</head>

<body class="h-100">
    <div class="authincation h-100">
        <div class="container-fluid h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">                    
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
                                    <div class="text-center"><img src="<?php echo $weburl.$logoweb;?>" style="max-width: 150px;"/></div>
                                    <h4 class="text-center mb-4">Login ke Dashboard</h4>
                                    <?php 
                                    if (isset($error) && !empty($error)) { 
                                      echo '
                                      <div class="alert alert-danger alert-dismissible alert-alt solid fade show">
                                      <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i class="mdi mdi-close"></i></span>
                                      </button>
                                        <strong>Error!</strong> '.$error.'.
                                      </div>'; 
                                    } 
                                    ?>
                                    <form action="" method="post">
                                        <div class="form-group">
                                            <label><strong>Email</strong></label>
                                            <input type="email" class="form-control" name="username" placeholder="email@example.com">
                                        </div>
                                        <div class="form-group">
                                            <label><strong>Password</strong></label>
                                            <div class="password-wrapper">
                                              <input type="password" class="form-control" id="password" name="password">
                                              <span class="toggle-password" id="togglePassword" onclick="togglePassword()"><i class="fas fa-eye text-secondary"></i></span>
                                            </div>
                                        </div>                                        
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary btn-block">L o g i n</button>
                                        </div>
                                    </form>
                                    <div class="row mt-3">
                                      <div class="col text-left">
                                        <a href="register">Register</a>
                                      </div>
                                      <div class="col text-right">
                                        <a href="reset">Reset Password</a>
                                      </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?=$weburl;?>theme/focus/vendor/global/global.min.js"></script>
</body>

</html>