<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?php echo $head['pagetitle'] ??= 'Dashboard';?></title>
  <!-- Favicon icon -->
  <link rel="icon" type="image/png" sizes="16x16" href="<?= $weburl.$favicon;?>">
  <link href="<?=$weburl;?>theme/focus/css/style.css" rel="stylesheet">
  <link href="<?=$weburl;?>fontawesome/css/fontawesome.min.css" rel="stylesheet" />
  <link href="<?=$weburl;?>fontawesome/css/regular.min.css" rel="stylesheet" />
  <link href="<?=$weburl;?>fontawesome/css/solid.min.css" rel="stylesheet" />
  <link href="<?=$weburl;?>editor/css/froala_style.min.css" rel="stylesheet" type="text/css" />
  <?php echo $head['scripthead']??=''; ?>
</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php if (isset($settings['logoteks']) && !empty($settings['logoteks'])) {
            $logoteks = $weburl.'upload/'.$settings['logoteks'];
        } else {
            $logoteks = $weburl.'theme/focus/images/logo-text.png';
        }
        ?>
        <div class="nav-header">
            <a href="<?= $weburl;?>dashboard" class="brand-logo">
                <img class="logo-abbr" src="<?= $weburl.$logoweb;?>" alt="">
                <img class="logo-compact" src="<?=$logoteks;?>" alt="">
                <img class="brand-title" src="<?=$logoteks;?>" alt="">
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="header-left">
                            
                        </div>

                        <ul class="navbar-nav header-right">                            
                          <li class="nav-item dropdown header-profile">
                            <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                              <img src="<?= isset($datamember['fotoprofil']) ? $weburl.'upload/'.$datamember['fotoprofil'] : $weburl.'img/pp.png';?>" alt="mdo" width="32" height="32" class="rounded-circle">
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                              <?php if (isset($datamember['mem_id'])) :?>
                              <a href="<?= $weburl;?>profil" class="dropdown-item">
                                  <i class="fa-solid fa-user"></i>
                                  <span class="ml-2">Profile </span>
                              </a>
                              <a href="<?= $weburl;?>orderanda" class="dropdown-item">
                                  <i class="fa-solid fa-cart-shopping"></i>
                                  <span class="ml-2">Pesanan </span>
                              </a>
                              <a href="<?= $weburl;?>logout" class="dropdown-item">
                                  <i class="fa-solid fa-right-from-bracket"></i>
                                  <span class="ml-2">Logout </span>
                              </a>
                              <?php else : ?>
                                <a class="dropdown-item" href="<?= $weburl;?>login"><i class="fa-solid fa-unlock-keyhole"></i> <span class="ml-2">Login</span></a>
                                <a class="dropdown-item" href="<?= $weburl;?>register"><i class="fa-solid fa-pen-to-square"></i> <span class="ml-2">Register</span></a>
                              <?php endif; ?>
                            </div>
                          </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="quixnav">
            <div class="quixnav-scroll">
                <ul class="metismenu" id="menu">
                  <?php 
                  include('menu.php'); ?>
                </ul>
            </div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
          <!-- row -->
          <div class="container-fluid">            
            <div class="row page-titles mx-0">
              
              <div class="col-sm-6 p-md-0">
                <?php if (is_login()) :?>
                <div class="welcome-text">
                  <h4>Hi, <?= $datamember['mem_nama'];?>!</h4>
                </div>
                <?php endif;?>
              </div>
              
              <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?= $weburl.'dashboard';?>">Dashboard</a></li>
                  <?php 
                  if (isset($_GET['edit'])) {
                    if (is_numeric($_GET['edit'])) {
                      $act = 'Edit ';
                    } else {
                      $act = 'Tambah ';
                    }
                    echo '
                    <li class="breadcrumb-item"><a href="'.$weburl.'dashboard/'.$bcslug.'">'.$bcjudul.'</a></li>
                    <li class="breadcrumb-item active" aria-current="page">'.$act.$bcjudul.'</li>';
                  } elseif (isset($_GET['detil'])) {
                    echo '
                    <li class="breadcrumb-item"><a href="'.$weburl.'dashboard/'.$bcslug.'">'.$bcjudul.'</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Detil '.$bcjudul.'</li>';
                  } else {
                    echo '<li class="breadcrumb-item active" aria-current="page">'.$bcjudul.'</li>';
                  }
                  ?>
                </ol>
              </div>
            </div>
           