<?php
ob_start(); // Mulai output buffering
$convertfile = str_replace('focus','simple',$convertfile);
include caripath('theme').'/'.$convertfile;
$isiindex = ob_get_clean();
$isiindex = str_replace('form-select', 'form-control', $isiindex);
$isiindex = str_replace('table-secondary', 'thead-primary', $isiindex);
$isiindex = str_replace('form-color form-control-color', 'form-control', $isiindex);
$isiindex = str_replace('text-end', 'text-right', $isiindex);
$isiindex = str_replace('<div class="alert alert-success alert-dismissible fade show" role="alert">',
	'<div class="alert alert-success alert-dismissible alert-alt solid fade show">
    <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i class="mdi mdi-close"></i></span>
    </button>',$isiindex);
$isiindex = str_replace('<div class="alert alert-danger alert-dismissible fade show" role="alert">',
	'<div class="alert alert-danger alert-dismissible alert-alt solid fade show">
    <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i class="mdi mdi-close"></i></span>
    </button>',$isiindex);
$isiindex = str_replace('<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',	'',$isiindex);
$isiindex = preg_replace_callback('/<div class="card-header">(.*?)<\/div>/s', function ($match) {
    $judul = trim($match[1]);
    return '<div class="card-header"><div class="card-title">' . $judul . '</div></div>';
}, $isiindex);

$isiindex = preg_replace_callback('/<input\s+type="file"\s+class="form-control"([^>]*)>/i', function ($match) {
        // Tangkap semua atribut selain type dan class
        $name = trim($match[1]);
        return '<div class="custom-file"><input type="file" class="custom-file-input"' . $name . '> 
        <label class="custom-file-label">Pilih file</label></div>';
    }, $isiindex);

# Tambahan Settings
if (isset($settings['logoteks']) && $settings['logoteks'] != '') {
  $logoteks = '<img src="'.$weburl.'upload/'.$settings['logoteks'].'?id='.rand(100,999).'" class="img-fluid img-thumbnail" style="max-width: 100px">';
} else {
  $logoteks = '';
}

$isiindex = str_replace('<label class="col-sm-2 col-form-label">Favicon</label>','    
      <label class="col-sm-2 col-form-label">Logo Teks</label>
      <div class="col-sm-10">
        <div class="custom-file">
          <input type="file" class="custom-file-input"name="logoteks"> 
          <label class="custom-file-label">Pilih file</label></div>
          <small class="form-text text-muted">Logo bentuk teks yg muncul saat sidebar dibuka dan hilang saat sidebar ditutup</small>
          <div class="mt-2" id="previewlogoteks">
          '.$logoteks.'
        </div>
      </div>
    </div>
    <div class="mb-3 row">
      <label class="col-sm-2 col-form-label">Favicon</label>',$isiindex);
echo $isiindex;